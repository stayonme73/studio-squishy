"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, type ReactNode } from "react";

import JourneyRail from "@/components/studio-board/JourneyRail";
import StudioBoardDevStatus from "@/components/studio-board/StudioBoardDevStatus";
import {
  studioBoard,
  studioBoardDraftRoomHref,
  studioBoardPrimaryHref,
  type CampaignStatus,
} from "@/config/studio-board";
import {
  greetingPeriodFromDate,
  resolveMembershipSnapshot,
  resolveStudioBoardView,
  type GreetingPeriod,
} from "@/lib/studio-board-view";
import { useCurrentCampaign } from "@/lib/use-current-campaign";

const {
  assets,
  bottomBar,
  sidebar,
  pageTitle,
  userName,
  notesCopy,
  whatHappensNextCopy,
  campaignNameLabel,
  empty: emptyCopy,
  membership: membershipDefaults,
} = studioBoard;

function useLiveGreetingPeriod() {
  const [period, setPeriod] = useState<GreetingPeriod | null>(null);

  useEffect(() => {
    setPeriod(greetingPeriodFromDate());
    const interval = window.setInterval(() => setPeriod(greetingPeriodFromDate()), 60_000);
    return () => window.clearInterval(interval);
  }, []);

  return period;
}

function DecorativeArt({
  src,
  className,
}: {
  src: string;
  className?: string;
}) {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  return (
    <div
      className={`sb-art-wrap${loaded ? " sb-art-wrap--loaded" : ""}${className ? ` ${className}` : ""}`}
    >
      {!failed ? (
        <img
          src={src}
          alt=""
          className="sb-art"
          decoding="async"
          onLoad={() => setLoaded(true)}
          onError={() => setFailed(true)}
        />
      ) : null}
    </div>
  );
}

function studioNoteState(
  index: number,
  total: number,
  status: CampaignStatus | null,
): "complete" | "current" | "upcoming" {
  if (!status) return index === 0 ? "current" : "upcoming";
  if (status === "DELIVERED") return "complete";

  const activeIndex: Record<CampaignStatus, number> = {
    DRAFT_RECEIVED: 1,
    BUILDING_CONCEPTS: 2,
    READY_FOR_REVIEW: Math.min(2, total - 1),
    FINAL_ASSETS_IN_PROGRESS: total - 1,
    DELIVERED: total,
  };

  const current = activeIndex[status];
  if (index < current) return "complete";
  if (index === current) return "current";
  return "upcoming";
}

function SidebarIcon({ name }: { name: "board" | "new" | "past" | "account" | "help" }) {
  switch (name) {
    case "board":
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
          <rect x="3" y="3" width="8" height="8" rx="1.5" />
          <rect x="13" y="3" width="8" height="8" rx="1.5" />
          <rect x="3" y="13" width="8" height="8" rx="1.5" />
          <rect x="13" y="13" width="8" height="8" rx="1.5" />
        </svg>
      );
    case "new":
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
          <circle cx="12" cy="12" r="9" />
          <path d="M12 8v8M8 12h8" strokeLinecap="round" />
        </svg>
      );
    case "past":
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
          <path d="M7 4h10l3 3v13H7V4z" strokeLinejoin="round" />
          <path d="M17 4v3h3M9 11h6M9 15h4" strokeLinecap="round" />
        </svg>
      );
    case "account":
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
          <circle cx="12" cy="8" r="3.5" />
          <path d="M5 20c1.5-3 4.5-4.5 7-4.5s5.5 1.5 7 4.5" strokeLinecap="round" />
        </svg>
      );
    case "help":
      return (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
          <circle cx="12" cy="12" r="9" />
          <path d="M9.5 9.25a2.75 2.75 0 0 1 4.75 1.75c0 1.75-2.25 2-2.25 3.75" strokeLinecap="round" />
          <circle cx="12" cy="17" r="0.75" fill="currentColor" stroke="none" />
        </svg>
      );
  }
}

function NavItem({
  href,
  active,
  icon,
  children,
}: {
  href?: string;
  active?: boolean;
  icon: "board" | "new" | "past" | "account" | "help";
  children: ReactNode;
}) {
  const className = `sb-nav__item${active ? " sb-nav__item--active" : " sb-nav__item--link"}`;
  const content = (
    <>
      <span className="sb-nav__icon" aria-hidden>
        <SidebarIcon name={icon} />
      </span>
      <span className="sb-nav__label">{children}</span>
    </>
  );

  if (href) {
    return (
      <Link href={href} className={className}>
        {content}
      </Link>
    );
  }

  return <span className={className}>{content}</span>;
}

/** Studio Board V1 — mockup-faithful layout + decorative art. */
export default function StudioBoardScene() {
  const { campaign, ready } = useCurrentCampaign();
  const greetingPeriod = useLiveGreetingPeriod();
  const view = useMemo(() => resolveStudioBoardView(campaign), [campaign]);
  const membership = useMemo(() => resolveMembershipSnapshot(campaign), [campaign]);

  const draftRoomHref = useMemo(
    () => studioBoardDraftRoomHref(campaign?.packageId ?? membershipDefaults.packageId),
    [campaign?.packageId],
  );

  const primaryHref =
    view.hasCampaign && view.primaryRoute
      ? studioBoardPrimaryHref(view.primaryRoute)
      : draftRoomHref;

  const planProgress = Math.round((membership.campaignsUsed / membership.campaignsTotal) * 100);

  return (
    <div className="sb" aria-label="Studio Board" aria-busy={!ready}>
      <aside className="sb-sidebar">
        <div className="sb-brand">
          <p className="sb-brand__the">the</p>
          <div className="sb-brand__lockup">
            <span className="sb-brand__icon" aria-hidden>
              <svg viewBox="0 0 32 32" fill="none">
                <path
                  d="M16 4v2M16 26v2M4 16h2M26 16h2M7.05 7.05l1.42 1.42M23.53 23.53l1.42 1.42M7.05 24.95l1.42-1.42M23.53 8.47l1.42-1.42"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                />
                <path
                  d="M16 9c-3.2 0-5.5 2.2-5.5 5.2 0 2.1 1.2 3.4 2.4 4.3V20a3.6 3.6 0 0 0 6.2 0v-1.5c1.2-.9 2.4-2.2 2.4-4.3C21.5 11.2 19.2 9 16 9Z"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinejoin="round"
                />
                <path
                  d="M16 17.5v2.5"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                />
                <circle cx="16" cy="13.5" r="1.15" fill="currentColor" />
              </svg>
            </span>
            <div className="sb-brand__stack">
              <p className="sb-brand__name">STUDIO</p>
              <p className="sb-brand__by">BY SPARK</p>
            </div>
          </div>
        </div>

        <nav className="sb-nav" aria-label="Studio navigation">
          <NavItem active icon="board">
            {sidebar.studioBoard}
          </NavItem>
          <NavItem href={draftRoomHref} icon="new">
            {sidebar.newCampaign}
          </NavItem>
          <NavItem href={studioBoard.routes.pastCampaigns} icon="past">
            {sidebar.pastCampaigns}
          </NavItem>
          <NavItem href={studioBoard.routes.account} icon="account">
            {sidebar.account}
          </NavItem>
          <NavItem href={studioBoard.routes.helpCenter} icon="help">
            {sidebar.helpCenter}
          </NavItem>
        </nav>

        <div className="sb-sidebar-lower">
          <DecorativeArt src={assets.sidebarDesk} className="sb-sidebar-scene" />

          <div className="sb-plan">
            <div className="sb-plan__head">
              <span className="sb-plan__icon" aria-hidden>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
                  <path d="M12 3l7.5 7.5L12 21 4.5 10.5 12 3z" strokeLinejoin="round" />
                </svg>
              </span>
              <p className="sb-plan__title">{membership.packageType}</p>
            </div>
            <p className="sb-plan__usage">
              {membership.campaignsUsed} of {membership.campaignsTotal} campaigns used
            </p>
            <div className="sb-plan__bar" role="presentation">
              <span style={{ width: `${planProgress}%` }} />
            </div>
            <Link href={studioBoard.routes.account} className="sb-plan__link">
              {sidebar.managePlan} →
            </Link>
          </div>
        </div>
      </aside>

      <div className="sb-main">
        <header className="sb-header">
          <DecorativeArt src={assets.headerBanner} className="sb-header__banner" />
          <div className="sb-header__copy">
            <h1 className="sb-header__title">{pageTitle}</h1>
            {greetingPeriod ? (
              <p className="sb-header__greeting">
                Good {greetingPeriod}
                {view.hasCampaign ? (
                  <>
                    , <span className="sb-header__name">{userName}</span>.
                  </>
                ) : (
                  "."
                )}
              </p>
            ) : (
              <p className="sb-header__greeting sb-header__greeting--loading" aria-busy="true" />
            )}
            <p className="sb-header__sub">{view.headerSubline}</p>
          </div>
        </header>

        <div className="sb-grid">
          <article className="sb-card sb-card--campaign" aria-labelledby="sb-campaign-title">
            <div className="sb-campaign" aria-live="polite">
              <div className="sb-campaign__layout">
                <section
                  className="sb-campaign__col sb-campaign__col--main"
                  aria-labelledby="sb-campaign-title"
                >
                  <p className="sb-campaign__badge">Current Campaign</p>
                  <span className="sb-campaign__field-label sb-campaign__field-label--name">
                    {campaignNameLabel}
                  </span>
                  <span className="sb-campaign__icon" aria-hidden>
                    <svg viewBox="0 0 48 48" fill="none">
                      <circle cx="24" cy="24" r="21" stroke="currentColor" strokeWidth="1.75" />
                      <path
                        d="M24 14v20M18 20h12a4 4 0 0 1 0 8h-8a4 4 0 0 0 0 8h12"
                        stroke="currentColor"
                        strokeWidth="1.75"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </span>
                  <h2
                    id="sb-campaign-title"
                    className={`sb-campaign__name${view.hasCampaign ? "" : " sb-campaign__name--empty"}`}
                  >
                    {view.hasCampaign ? view.campaignName : emptyCopy.campaignNamePlaceholder}
                  </h2>
                  {view.stickySelection ? (
                    <>
                      <span className="sb-campaign__field-label">Selected direction</span>
                      <p className="sb-campaign__selected">{view.stickySelection}</p>
                    </>
                  ) : null}
                </section>

                <section className="sb-campaign__col sb-campaign__col--status">
                  <span className="sb-campaign__field-label">Status</span>
                  {view.hasCampaign ? (
                    <p className="sb-campaign__status">{view.statusLabel}</p>
                  ) : (
                    <p className="sb-campaign__status sb-campaign__status--empty">Not started yet</p>
                  )}
                  {view.estimatedCompletion ? (
                    <div className="sb-campaign__eta">
                      <span className="sb-campaign__eta-label">Estimated completion</span>
                      <span className="sb-campaign__eta-value">{view.estimatedCompletion}</span>
                    </div>
                  ) : null}
                  <Link href={primaryHref} className="sb-btn sb-btn--campaign">
                    {view.primaryCta} →
                  </Link>
                </section>

                <section className="sb-campaign__col sb-campaign__col--journey">
                  <JourneyRail status={view.status} layout="vertical" />
                </section>
              </div>
            </div>
          </article>

          <section className="sb-card sb-card--notes" aria-labelledby="sb-notes-title">
            <div className="sb-notes__header">
              <h2 id="sb-notes-title" className="sb-notes__heading">
                {notesCopy.heading}
              </h2>
            </div>

            <p className="sb-notes__readonly">{notesCopy.readOnlyHint}</p>

            <ul className="sb-notes">
              {view.studioNotes.map((note, index) => {
                const state = studioNoteState(index, view.studioNotes.length, view.status);
                return (
                  <li key={`${note}-${index}`} className={`sb-notes__item sb-notes__item--${state}`}>
                    <span className="sb-notes__marker" aria-hidden>
                      {state === "complete" ? "✓" : null}
                    </span>
                    <span className="sb-notes__text">{note}</span>
                  </li>
                );
              })}
            </ul>

            <Link
              href={
                view.hasCampaign
                  ? studioBoard.routes.campaignDetails
                  : studioBoard.routes.helpCenter
              }
              className="sb-notes__footer"
            >
              {notesCopy.viewAllUpdates} →
            </Link>
          </section>

          <section className="sb-card sb-card--next" aria-labelledby="sb-next-title">
            <div className="sb-next">
              <DecorativeArt src={assets.whatsNextRoom} className="sb-next__photo" />
              <div className="sb-next__content">
                <h2 id="sb-next-title" className="sb-next__heading">
                  <span className="sb-next__heading-mark">What</span> Happens Next?
                </h2>
                <p className="sb-next__copy">{view.whatHappensNext}</p>
              </div>
              <aside className="sb-next__sticky" aria-label="Studio note">
                <span className="sb-tape sb-tape--polaroid sb-tape--on-next" aria-hidden />
                <p className="sb-next__sticky-text">
                  {whatHappensNextCopy.stickyDefaultLines.map((line, index) => (
                    <span key={line}>
                      {line}
                      {index < whatHappensNextCopy.stickyDefaultLines.length - 1 ? <br /> : null}
                    </span>
                  ))}
                </p>
                <svg
                  className="sb-next__sticky-heart"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.75"
                  aria-hidden
                >
                  <path d="M12 20.5s-6.5-4.2-8.5-8.2C2.2 9.1 3.6 6 6.5 6c1.7 0 3.2 1 4 2.5.8-1.5 2.3-2.5 4-2.5 2.9 0 4.3 3.1 3 6.3-2 4-8.5 8.2-8.5 8.2z" />
                </svg>
              </aside>
            </div>
          </section>

          <section className="sb-card sb-card--membership" aria-labelledby="sb-membership-title">
            <h2 id="sb-membership-title" className="sb-membership__heading">
              Membership Snapshot
            </h2>
            {membership.isActive ? (
              <>
                <dl className="sb-membership__stats">
                  <div className="sb-membership__row">
                    <span className="sb-membership__icon" aria-hidden>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
                        <rect x="3" y="4" width="18" height="18" rx="2" />
                        <path d="M3 10h18M8 2v4M16 2v4" />
                        <path d="M13 12l-2.5 4h2l-1.5 3" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </span>
                    <div className="sb-membership__line">
                      <dt className="sb-membership__label">Campaigns Remaining</dt>
                      <span className="sb-membership__leader" aria-hidden />
                      <dd className="sb-membership__value">{membership.campaignsRemaining} left</dd>
                    </div>
                  </div>
                  <div className="sb-membership__row">
                    <span className="sb-membership__icon" aria-hidden>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
                        <rect x="2" y="5" width="20" height="14" rx="2" />
                        <path d="M2 7l10 7 10-7" />
                      </svg>
                    </span>
                    <div className="sb-membership__line">
                      <dt className="sb-membership__label">Emails Remaining</dt>
                      <span className="sb-membership__leader" aria-hidden />
                      <dd className="sb-membership__value">{membership.emailsRemaining} left</dd>
                    </div>
                  </div>
                  <div className="sb-membership__row">
                    <span className="sb-membership__icon" aria-hidden>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
                        <rect x="7" y="2" width="10" height="20" rx="2" />
                        <path d="M11 18h2" strokeLinecap="round" />
                      </svg>
                    </span>
                    <div className="sb-membership__line">
                      <dt className="sb-membership__label">SMS Remaining</dt>
                      <span className="sb-membership__leader" aria-hidden />
                      <dd className="sb-membership__value">{membership.smsRemaining} left</dd>
                    </div>
                  </div>
                </dl>
                <hr className="sb-membership__divider" />
                <dl className="sb-membership__renewal">
                  <div className="sb-membership__row">
                    <span className="sb-membership__icon" aria-hidden>
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75">
                        <rect x="3" y="4" width="18" height="18" rx="2" />
                        <path d="M3 10h18M8 2v4M16 2v4" />
                        <path d="M12 14.5v3M10 16h4" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </span>
                    <div className="sb-membership__line">
                      <dt className="sb-membership__label">Renewal Date</dt>
                      <span className="sb-membership__leader" aria-hidden />
                      <dd className="sb-membership__value">{membership.renewalDate}</dd>
                    </div>
                  </div>
                </dl>
              </>
            ) : (
              <p className="sb-membership__empty">{membership.emptyHint}</p>
            )}
            <Link href={studioBoard.routes.account} className="sb-membership__link">
              {sidebar.managePlan} →
            </Link>
          </section>
        </div>

        <footer className="sb-footer">
          <span className="sb-footer__plus" aria-hidden>
            +
          </span>
          <p className="sb-footer__msg">{bottomBar.message}</p>
          <Link href={draftRoomHref} className="sb-btn sb-btn--teal sb-btn--footer">
            {bottomBar.cta}
          </Link>
        </footer>
      </div>
      <StudioBoardDevStatus />
    </div>
  );
}
