import { studioBoard, type CampaignRecord, type CampaignStatus, type StudioBoardPrimaryRoute } from "@/config/studio-board";

const { empty, statusContent } = studioBoard;

const defaultHeaderSubline = "Here's what's happening in the Studio today.";

export type StudioBoardView = {
  hasCampaign: boolean;
  status: CampaignStatus | null;
  campaignName: string;
  statusLabel: string;
  campaignDescription: string;
  estimatedCompletion: string | null;
  studioNotes: readonly string[];
  whatHappensNext: string;
  stickySelection: string | null;
  headerSubline: string;
  primaryCta: string;
  primaryRoute: StudioBoardPrimaryRoute | null;
};

/** Live board copy — always derived from current campaignStatus, never stale intake fields. */
export function resolveStudioBoardView(campaign: CampaignRecord | null): StudioBoardView {
  if (!campaign) {
    return {
      hasCampaign: false,
      status: null,
      campaignName: empty.campaignName,
      statusLabel: "Not started",
      campaignDescription: empty.campaignDescription,
      estimatedCompletion: null,
      studioNotes: empty.studioNotes,
      whatHappensNext: empty.campaignDescription,
      stickySelection: null,
      headerSubline: "Start a campaign to see your Studio journey unfold.",
      primaryCta: empty.primaryCta,
      primaryRoute: null,
    };
  }

  const content = statusContent[campaign.campaignStatus];

  return {
    hasCampaign: true,
    status: campaign.campaignStatus,
    campaignName: campaign.campaignName,
    statusLabel: content.statusLabel,
    campaignDescription: content.campaignDescription,
    estimatedCompletion: content.estimatedCompletion,
    studioNotes: content.studioNotes,
    whatHappensNext: content.whatHappensNext,
    stickySelection: campaign.selectedCampaignOption ?? null,
    headerSubline: defaultHeaderSubline,
    primaryCta: content.primaryCta,
    primaryRoute: content.primaryRoute,
  };
}

export type MembershipSnapshotView = {
  isActive: boolean;
  emptyHint: string;
  packageType: string;
  campaignsRemaining: number;
  campaignsTotal: number;
  campaignsUsed: number;
  emailsRemaining: number;
  smsRemaining: number;
  renewalDate: string;
};

/** Phase 1 — mock plan usage tied to whether a campaign is in progress. */
export function resolveMembershipSnapshot(
  campaign: CampaignRecord | null,
): MembershipSnapshotView {
  const base = studioBoard.membership;

  if (!campaign) {
    return {
      isActive: false,
      emptyHint: base.emptyHint,
      packageType: base.packageType,
      campaignsRemaining: base.campaignsTotal,
      campaignsTotal: base.campaignsTotal,
      campaignsUsed: 0,
      emailsRemaining: base.emailsRemaining,
      smsRemaining: base.smsRemaining,
      renewalDate: base.renewalDate,
    };
  }

  return {
    isActive: true,
    emptyHint: base.emptyHint,
    packageType: base.packageType,
    campaignsRemaining: base.campaignsRemaining,
    campaignsTotal: base.campaignsTotal,
    campaignsUsed: base.campaignsTotal - base.campaignsRemaining,
    emailsRemaining: base.emailsRemaining,
    smsRemaining: base.smsRemaining,
    renewalDate: base.renewalDate,
  };
}

export type GreetingPeriod = "morning" | "afternoon" | "evening";

export function greetingPeriodFromDate(date = new Date()): GreetingPeriod {
  const hour = date.getHours();
  if (hour < 12) return "morning";
  if (hour < 17) return "afternoon";
  return "evening";
}
