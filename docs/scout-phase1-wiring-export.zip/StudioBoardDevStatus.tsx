"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

import { DEV_STATUS_OPTIONS } from "@/lib/studio-board-dev-status";
import { clearCampaignState } from "@/lib/studio-board-campaign";

/** Dev-only toolbar — not shown in production builds. */
export default function StudioBoardDevStatus() {
  if (process.env.NODE_ENV !== "development") return null;

  const pathname = usePathname();
  const router = useRouter();

  function handleReset() {
    clearCampaignState();
    router.replace(pathname);
  }

  return (
    <div className="sb-dev-status" aria-label="Developer tools">
      <p className="sb-dev-status__label">Dev tools (local only)</p>
      <p className="sb-dev-status__hint">
        Jump campaign status for testing, or reset to start the intake flow fresh.
      </p>
      <div className="sb-dev-status__buttons">
        {DEV_STATUS_OPTIONS.map(({ param, label }) => (
          <Link
            key={param}
            href={`${pathname}?status=${param}`}
            className="sb-dev-status__btn"
          >
            {label}
          </Link>
        ))}
        <button type="button" className="sb-dev-status__btn sb-dev-status__btn--reset" onClick={handleReset}>
          Reset campaign
        </button>
      </div>
    </div>
  );
}
