"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo } from "react";

import StudioBoardDevStatus from "@/components/studio-board/StudioBoardDevStatus";
import { reviewRoom } from "@/config/review-room";
import { studioBoard } from "@/config/studio-board";
import { selectCampaignOption } from "@/lib/studio-board-campaign";
import { useCurrentCampaign } from "@/lib/use-current-campaign";

/** Review Room — choose A / B / C (Phase 1). */
export default function ReviewRoomScene() {
  const router = useRouter();
  const { campaign, ready } = useCurrentCampaign();

  const selectedOption = campaign?.selectedCampaignOption ?? null;
  const isReviewReady = campaign?.campaignStatus === "READY_FOR_REVIEW";

  const pageState = useMemo(() => {
    if (!campaign) return "no-campaign" as const;
    if (!isReviewReady) return "not-ready" as const;
    return "ready" as const;
  }, [campaign, isReviewReady]);

  function handleSelect(optionTitle: string) {
    selectCampaignOption(optionTitle);
    router.push(studioBoard.routes.studioBoard);
  }

  if (!ready) {
    return (
      <div className="rr" aria-busy="true">
        <div className="rr-shell rr-shell--loading" />
      </div>
    );
  }

  if (pageState === "no-campaign") {
    return (
      <div className="rr">
        <div className="rr-shell rr-shell--empty">
          <p className="rr-eyebrow">{reviewRoom.eyebrow}</p>
          <h1 className="rr-title">{reviewRoom.noCampaign.title}</h1>
          <p className="rr-lead">{reviewRoom.noCampaign.body}</p>
          <Link href={studioBoard.routes.studioBoard} className="rr-btn rr-btn--primary">
            {reviewRoom.noCampaign.cta} →
          </Link>
        </div>
        <StudioBoardDevStatus />
      </div>
    );
  }

  if (pageState === "not-ready") {
    return (
      <div className="rr">
        <div className="rr-shell rr-shell--empty">
          <p className="rr-eyebrow">{reviewRoom.eyebrow}</p>
          <h1 className="rr-title">{reviewRoom.notReady.title}</h1>
          <p className="rr-lead">{reviewRoom.notReady.body}</p>
          <Link href={studioBoard.routes.studioBoard} className="rr-btn rr-btn--primary">
            {reviewRoom.backLabel} →
          </Link>
        </div>
        <StudioBoardDevStatus />
      </div>
    );
  }

  return (
    <div className="rr" aria-label="Review Room">
      <header className="rr-header">
        <Link href={studioBoard.routes.studioBoard} className="rr-back">
          ← {reviewRoom.backLabel}
        </Link>
        <div className="rr-header__copy">
          <p className="rr-eyebrow">{reviewRoom.eyebrow}</p>
          <h1 className="rr-title">{reviewRoom.pageTitle}</h1>
          <p className="rr-lead">{reviewRoom.intro}</p>
        </div>
      </header>

      <div className="rr-options">
        {reviewRoom.options.map((option) => {
          const isSelected = selectedOption === option.title;
          return (
            <article key={option.id} className="rr-card">
              <div className="rr-card__badge">{option.id}</div>
              <h2 className="rr-card__title">{option.title}</h2>
              <p className="rr-card__tagline">{option.tagline}</p>
              <p className="rr-card__body">{option.description}</p>
              {isSelected ? (
                <p className="rr-card__selected">{reviewRoom.selectedBadge}</p>
              ) : (
                <button
                  type="button"
                  className="rr-btn rr-btn--primary"
                  onClick={() => handleSelect(option.title)}
                >
                  {reviewRoom.selectCta} →
                </button>
              )}
            </article>
          );
        })}
      </div>

      <StudioBoardDevStatus />
    </div>
  );
}
