import type { CampaignStatus } from "@/config/studio-board";

/** Dev-only query param → campaign status (Phase 1 testing). */
export const DEV_STATUS_QUERY_MAP: Record<string, CampaignStatus> = {
  draft: "DRAFT_RECEIVED",
  concepts: "BUILDING_CONCEPTS",
  review: "READY_FOR_REVIEW",
  delivery: "FINAL_ASSETS_IN_PROGRESS",
  delivered: "DELIVERED",
};

export const DEV_STATUS_OPTIONS = [
  { param: "draft", label: "Draft Received" },
  { param: "concepts", label: "Building Concepts" },
  { param: "review", label: "Review & Approval" },
  { param: "delivery", label: "Final Delivery" },
  { param: "delivered", label: "Delivered" },
] as const;

export function parseDevStatusParam(
  searchParams: URLSearchParams | ReadonlyURLSearchParams,
): CampaignStatus | null {
  const raw = searchParams.get("status")?.trim().toLowerCase();
  if (!raw) return null;
  return DEV_STATUS_QUERY_MAP[raw] ?? null;
}

type ReadonlyURLSearchParams = Pick<URLSearchParams, "get">;
