import {
  campaignStatusIndex,
  studioBoard,
  type CampaignStatus,
} from "@/config/studio-board";

const { journeyStages } = studioBoard;

export default function JourneyRail({
  status,
  layout = "vertical",
}: {
  status: CampaignStatus | null;
  layout?: "vertical" | "horizontal";
}) {
  const activeIndex = status ? campaignStatusIndex(status) : -1;

  return (
    <ol
      className={`sb-journey sb-journey--${layout}`}
      aria-label="Campaign journey"
    >
      {journeyStages.map((stage, index) => {
        const isComplete = activeIndex >= 0 && index < activeIndex;
        const isCurrent = activeIndex === index;
        const state = isCurrent ? "current" : isComplete ? "complete" : "upcoming";

        return (
          <li key={stage.id} className={`sb-journey__step sb-journey__step--${state}`}>
            <span className="sb-journey__dot" aria-hidden>
              {isComplete ? "✓" : null}
            </span>
            <div className="sb-journey__copy">
              <span className="sb-journey__label">{stage.label}</span>
              {layout === "vertical" && "hint" in stage ? (
                <span className="sb-journey__hint">{stage.hint}</span>
              ) : null}
            </div>
          </li>
        );
      })}
    </ol>
  );
}
