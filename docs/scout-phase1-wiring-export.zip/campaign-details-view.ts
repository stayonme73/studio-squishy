import {
  studioBoard,
  type CampaignRecord,
  type CampaignStatus,
} from "@/config/studio-board";

const { campaignDetails: copy, statusContent } = studioBoard;

export type DeliverablesPreview =
  | { ready: false; message: string; hint: string }
  | {
      ready: true;
      links: readonly { label: string; href: string }[];
    };

export type CampaignDetailsView = {
  hasCampaign: boolean;
  campaignName: string;
  statusLabel: string;
  status: CampaignStatus | null;
  estimatedCompletion: string;
  createdDate: string;
  campaignType: string;
  originalRequest: string;
  intakeSummary: {
    goal: string;
    audience: string;
    timeline: string;
    budget: string;
  };
  studioNotes: readonly string[];
  deliverables: DeliverablesPreview;
};

function formatCreatedDate(iso: string) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return copy.notProvided;
  return date.toLocaleDateString(undefined, {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
}

function intakeValue(value: string | undefined) {
  const trimmed = value?.trim();
  return trimmed ? trimmed : copy.notProvided;
}

function resolveDeliverables(status: CampaignStatus): DeliverablesPreview {
  const preparing = {
    ready: false as const,
    message: copy.deliverables.preparing,
    hint: copy.deliverables.preparingHint,
  };

  if (status === "READY_FOR_REVIEW") {
    return {
      ready: true,
      links: [{ label: copy.deliverables.reviewConcepts, href: studioBoard.routes.reviewRoom }],
    };
  }

  if (status === "DELIVERED") {
    return {
      ready: true,
      links: [{ label: copy.deliverables.viewFinalAssets, href: studioBoard.routes.deliverables }],
    };
  }

  return preparing;
}

export function resolveCampaignDetailsView(
  campaign: CampaignRecord | null,
): CampaignDetailsView {
  if (!campaign) {
    return {
      hasCampaign: false,
      campaignName: copy.notProvided,
      statusLabel: copy.notProvided,
      status: null,
      estimatedCompletion: copy.notProvided,
      createdDate: copy.notProvided,
      campaignType: copy.notProvided,
      originalRequest: copy.notProvided,
      intakeSummary: {
        goal: copy.notProvided,
        audience: copy.notProvided,
        timeline: copy.notProvided,
        budget: copy.notProvided,
      },
      studioNotes: studioBoard.empty.studioNotes,
      deliverables: {
        ready: false,
        message: copy.deliverables.preparing,
        hint: copy.deliverables.preparingHint,
      },
    };
  }

  const content = statusContent[campaign.campaignStatus];
  const intake = campaign.intake;

  return {
    hasCampaign: true,
    campaignName: campaign.campaignName,
    statusLabel: content.statusLabel,
    status: campaign.campaignStatus,
    estimatedCompletion: campaign.estimatedCompletion,
    createdDate: formatCreatedDate(campaign.createdAt),
    campaignType: campaign.packageLabel,
    originalRequest: intakeValue(intake?.idea),
    intakeSummary: {
      goal: intakeValue(intake?.action),
      audience: intakeValue(intake?.audience),
      timeline: intakeValue(intake?.deadline),
      budget: campaign.packageLabel,
    },
    studioNotes: content.studioNotes,
    deliverables: resolveDeliverables(campaign.campaignStatus),
  };
}
