/** Studio Board V1 — calm check-in experience (LOCKED). */

import type { StudioGuidePackageId } from "@/config/studio-guide";

export const CAMPAIGN_STATUSES = [
  "DRAFT_RECEIVED",
  "BUILDING_CONCEPTS",
  "READY_FOR_REVIEW",
  "FINAL_ASSETS_IN_PROGRESS",
  "DELIVERED",
] as const;

export type CampaignStatus = (typeof CAMPAIGN_STATUSES)[number];

export type CampaignIntakeSnapshot = {
  idea: string;
  audience: string;
  action: string;
  deadline: string;
  submittedAt: string;
};

export type CampaignRecord = {
  campaignId: string;
  campaignName: string;
  campaignStatus: CampaignStatus;
  campaignDescription: string;
  estimatedCompletion: string;
  selectedCampaignOption?: string;
  packageId: StudioGuidePackageId;
  packageLabel: string;
  intake?: CampaignIntakeSnapshot;
  createdAt: string;
  updatedAt: string;
};

export type MembershipRecord = {
  packageType: string;
  packageId: StudioGuidePackageId;
  campaignsRemaining: number;
  campaignsTotal: number;
  emailsRemaining: number;
  smsRemaining: number;
  renewalDate: string;
};

export const studioBoard = {
  userName: "Tagia",
  pageTitle: "The Studio Board",
  campaignNameLabel: "Campaign name",

  assets: {
    /** Full header banner — text left, scene right (live copy overlays left). */
    headerBanner: "/studio-board/studio-board-header-scene-v4.png?v=1",
    /** Sidebar art — drafting desk + city window. */
    sidebarDesk: "/studio-board/studio-board-sidebar-desk-v1.png?v=1",
    whatsNextRoom: "/studio-board/studio-board-team-v1.png?v=1",
  },

  routes: {
    studioBoard: "/studio-board",
    newCampaign: "/draft-room?package=momentum",
    draftRoom: "/draft-room",
    pastCampaigns: "/past-campaigns",
    account: "/account",
    helpCenter: "/help-center",
    reviewRoom: "/review-room",
    deliverables: "/deliverables",
    campaignDetails: "/campaign-details",
  },

  empty: {
    campaignName: "No campaign started yet.",
    campaignNamePlaceholder: "Your campaign name",
    campaignDescription: "Start a campaign to begin your Studio journey.",
    studioNotes: ["Start a campaign to see updates here."] as const,
    primaryCta: "START A NEW CAMPAIGN",
  },

  membership: {
    packageType: "Momentum Plan",
    packageId: "momentum" as const,
    campaignsRemaining: 1,
    campaignsTotal: 2,
    emailsRemaining: 5,
    smsRemaining: 5,
    renewalDate: "July 1, 2025",
    emptyHint: "Your plan usage appears here once you start a campaign.",
  } satisfies MembershipRecord & { emptyHint: string },

  journeyStages: [
    {
      id: "DRAFT_RECEIVED" as const,
      label: "Draft Received",
      hint: "We've got your request.",
    },
    {
      id: "BUILDING_CONCEPTS" as const,
      label: "Building Concepts",
      hint: "Our team is creating ideas.",
    },
    {
      id: "READY_FOR_REVIEW" as const,
      label: "Review & Approval",
      hint: "You'll review and choose.",
    },
    {
      id: "FINAL_ASSETS_IN_PROGRESS" as const,
      label: "Final Delivery",
      hint: "We deliver your assets.",
    },
    {
      id: "DELIVERED" as const,
      label: "Delivered",
      hint: "Your package is ready.",
    },
  ],

  statusContent: {
    DRAFT_RECEIVED: {
      statusLabel: "Draft Received",
      headerSubline: "Your draft is in — the Studio is getting started.",
      campaignDescription: "The Studio has received your draft and is preparing to begin.",
      estimatedCompletion: "2 days remaining",
      studioNotes: [
        "Draft submitted.",
        "Team assignment pending.",
        "Work in progress.",
        "More updates coming soon.",
      ],
      whatHappensNext:
        "Our team will review your draft and assign your creative team. You'll see updates here as work begins.",
      primaryCta: "VIEW DETAILS",
      primaryRoute: "campaignDetails" as const,
    },
    BUILDING_CONCEPTS: {
      statusLabel: "Building Concepts",
      headerSubline: "Your creative team is at work on campaign options.",
      campaignDescription: "The Studio is creating your campaign options with care and creativity.",
      estimatedCompletion: "2 days remaining",
      studioNotes: [
        "Draft submitted.",
        "Team assigned.",
        "Work in progress.",
        "More updates coming soon.",
      ],
      whatHappensNext:
        "Our creative team is crafting 3 unique campaign options tailored to your goals and audience. You'll be notified as soon as they're ready for your review.",
      primaryCta: "VIEW DETAILS",
      primaryRoute: "campaignDetails" as const,
    },
    READY_FOR_REVIEW: {
      statusLabel: "Ready for Review",
      headerSubline: "Your concepts are ready — the Studio needs your feedback.",
      campaignDescription: "Your campaign concepts are ready. The Studio needs your feedback.",
      estimatedCompletion: "Review when ready",
      studioNotes: [
        "Concepts completed.",
        "Review package ready.",
        "Customer review needed.",
      ],
      whatHappensNext:
        "Take a moment to review your campaign options. We'll move forward once you've chosen a direction.",
      primaryCta: "REVIEW CAMPAIGNS",
      primaryRoute: "reviewRoom" as const,
    },
    FINAL_ASSETS_IN_PROGRESS: {
      statusLabel: "Final Assets in Progress",
      headerSubline: "Final deliverables are being prepared for you.",
      campaignDescription: "The Studio is preparing your final campaign assets.",
      estimatedCompletion: "3 days remaining",
      studioNotes: ["Campaign selected.", "Final assets are being prepared."],
      whatHappensNext:
        "Your selected campaign is being refined into final deliverables. We'll let you know when everything is ready.",
      primaryCta: "VIEW DETAILS",
      primaryRoute: "campaignDetails" as const,
    },
    DELIVERED: {
      statusLabel: "Delivered",
      headerSubline: "Your campaign package is complete and ready.",
      campaignDescription: "Your campaign package is complete and ready for you.",
      estimatedCompletion: "Complete",
      studioNotes: ["Final package completed.", "Deliverables are ready."],
      whatHappensNext:
        "Your deliverables are ready to download and use. Start a new campaign whenever you're ready to grow again.",
      primaryCta: "VIEW DELIVERABLES",
      primaryRoute: "deliverables" as const,
    },
  },

  bottomBar: {
    message: "Need something else marketed? The Studio is here to help you grow.",
    cta: "START A NEW CAMPAIGN",
  },

  sidebar: {
    studioBoard: "Studio Board",
    newCampaign: "New Campaign",
    pastCampaigns: "Past Campaigns",
    account: "My Account",
    helpCenter: "Help Center",
    managePlan: "Manage Plan",
  },

  notesCopy: {
    viewAllUpdates: "VIEW ALL UPDATES",
    readOnlyHint: "Updates appear here automatically.",
    heading: "Studio Notes",
  },

  campaignDetails: {
    pageTitle: "Campaign Details",
    eyebrow: "Your Campaign",
    backLabel: "Back to Studio Board",
    sections: {
      overview: "Campaign Overview",
      originalRequest: "Original Request",
      intakeSummary: "Intake Summary",
      journey: "Campaign Journey",
      deliverables: "Deliverables Preview",
      updates: "Studio Updates",
    },
    originalRequestPrompt: "What would you like help marketing today?",
    overviewLabels: {
      name: "Campaign Name",
      status: "Current Status",
      estimatedCompletion: "Estimated Completion",
      createdDate: "Created Date",
      campaignType: "Campaign Type",
    },
    intakeLabels: {
      goal: "Goal",
      audience: "Audience",
      timeline: "Timeline",
      budget: "Budget",
    },
    deliverables: {
      preparing: "Deliverables are being prepared.",
      preparingHint: "Check back soon.",
      reviewConcepts: "Review Campaign Concepts",
      viewFinalAssets: "View Final Assets",
    },
    notProvided: "Not provided",
    empty: {
      title: "No campaign yet",
      body: "Start a campaign from the Draft Room to see your details here.",
      cta: "Go to Studio Board",
    },
  },

  whatHappensNextCopy: {
    title: "What Happens Next?",
    stickyDefaultLines: ["Great ideas", "take shape", "in the Studio."] as const,
    stickyLabel: "Selected campaign",
  },

  placeholders: {
    pastCampaigns: "Past Campaigns — coming soon.",
    account: "My Account — coming soon.",
    helpCenter: "Help Center — coming soon.",
    campaignDetails: "Campaign details — coming soon.",
  },
} as const;

export type StudioBoardPrimaryRoute =
  (typeof studioBoard.statusContent)[CampaignStatus]["primaryRoute"];

export function studioBoardDraftRoomHref(
  packageId: MembershipRecord["packageId"] = studioBoard.membership.packageId,
) {
  return `/draft-room?package=${packageId}`;
}

export function studioBoardPrimaryHref(route: StudioBoardPrimaryRoute | "newCampaign") {
  return studioBoard.routes[route];
}

export function campaignStatusIndex(status: CampaignStatus) {
  return CAMPAIGN_STATUSES.indexOf(status);
}
