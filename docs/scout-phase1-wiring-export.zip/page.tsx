import { Suspense } from "react";
import { Caveat, Inter } from "next/font/google";

import ReviewRoomScene from "@/components/review-room/ReviewRoomScene";

const caveat = Caveat({
  subsets: ["latin"],
  weight: ["600", "700"],
  variable: "--font-studio-board-script",
});

const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-studio-board-sans",
});

/** Review Room — campaign concept selection (Phase 1). */
export default function ReviewRoomPage() {
  return (
    <main
      className={`${inter.variable} ${caveat.variable} journey-shell flex min-h-[100dvh] flex-1 flex-col overflow-hidden bg-[#f5f0e8]`}
    >
      <Suspense fallback={<div className="rr rr-shell rr-shell--loading" aria-busy="true" />}>
        <ReviewRoomScene />
      </Suspense>
    </main>
  );
}
