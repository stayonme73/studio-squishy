import { Suspense } from "react";
import { Caveat, Inter } from "next/font/google";

import CampaignDetailsScene from "@/components/campaign-details/CampaignDetailsScene";

const caveat = Caveat({
  subsets: ["latin"],
  weight: ["600", "700"],
  variable: "--font-studio-board-script",
});

const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-studio-board-sans",
});

/** Campaign Details — read-only progress check-in (Phase 1). */
export default function CampaignDetailsPage() {
  return (
    <main
      className={`${inter.variable} ${caveat.variable} journey-shell flex min-h-[100dvh] flex-1 flex-col overflow-hidden bg-[#f5f0e8]`}
    >
      <Suspense fallback={<div className="cd cd-shell cd-shell--loading" aria-busy="true" />}>
        <CampaignDetailsScene />
      </Suspense>
    </main>
  );
}
