import {
  studioBoard,
  type CampaignRecord,
  type CampaignStatus,
} from "@/config/studio-board";
import type { DraftIntakePayload } from "@/config/draft-room";

const CAMPAIGN_KEY = "studio-squishy:current-campaign";
const DRAFT_KEY = "studio-squishy:last-draft";

function dispatchCampaignUpdated() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("studio-squishy:campaign-updated"));
  }
}

function campaignNameFromIdea(idea: string) {
  const trimmed = idea.trim();
  if (trimmed.length <= 64) return trimmed;
  return `${trimmed.slice(0, 61)}…`;
}

export function readCurrentCampaign(): CampaignRecord | null {
  if (typeof window === "undefined") return null;
  const raw = window.localStorage.getItem(CAMPAIGN_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as CampaignRecord;
  } catch {
    return null;
  }
}

export function saveCurrentCampaign(campaign: CampaignRecord) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(CAMPAIGN_KEY, JSON.stringify(campaign));
}

export function createCampaignFromIntake(payload: DraftIntakePayload): CampaignRecord {
  const content = studioBoard.statusContent.DRAFT_RECEIVED;
  const now = new Date().toISOString();

  return {
    campaignId: crypto.randomUUID(),
    campaignName: campaignNameFromIdea(payload.idea),
    campaignStatus: "DRAFT_RECEIVED",
    campaignDescription: content.campaignDescription,
    estimatedCompletion: content.estimatedCompletion,
    packageId: payload.packageId,
    packageLabel: payload.packageLabel,
    intake: {
      idea: payload.idea.trim(),
      audience: payload.audience.trim(),
      action: payload.action.trim(),
      deadline: payload.deadline.trim(),
      submittedAt: payload.submittedAt,
    },
    createdAt: now,
    updatedAt: now,
  };
}

export function updateCampaignStatus(status: CampaignStatus): CampaignRecord | null {
  const campaign = readCurrentCampaign();
  if (!campaign) return null;

  const content = studioBoard.statusContent[status];
  const updated: CampaignRecord = {
    ...campaign,
    campaignStatus: status,
    campaignDescription: content.campaignDescription,
    estimatedCompletion: content.estimatedCompletion,
    updatedAt: new Date().toISOString(),
  };

  saveCurrentCampaign(updated);
  dispatchCampaignUpdated();
  return updated;
}

/** Dev/testing — clear saved campaign + draft intake from this browser. */
export function clearCampaignState() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(CAMPAIGN_KEY);
  window.localStorage.removeItem(DRAFT_KEY);
  dispatchCampaignUpdated();
}

export function upsertCampaignFromIntake(payload: DraftIntakePayload) {
  const campaign = createCampaignFromIntake(payload);
  saveCurrentCampaign(campaign);
  dispatchCampaignUpdated();
  return campaign;
}

export function selectCampaignOption(optionLabel: string): CampaignRecord | null {
  const campaign = readCurrentCampaign();
  if (!campaign) return null;

  const content = studioBoard.statusContent.FINAL_ASSETS_IN_PROGRESS;
  const updated: CampaignRecord = {
    ...campaign,
    selectedCampaignOption: optionLabel,
    campaignStatus: "FINAL_ASSETS_IN_PROGRESS",
    campaignDescription: content.campaignDescription,
    estimatedCompletion: content.estimatedCompletion,
    updatedAt: new Date().toISOString(),
  };

  saveCurrentCampaign(updated);
  dispatchCampaignUpdated();
  return updated;
}
