"use client";

import Link from "next/link";
import { useMemo } from "react";

import JourneyRail from "@/components/studio-board/JourneyRail";
import StudioBoardDevStatus from "@/components/studio-board/StudioBoardDevStatus";
import { studioBoard } from "@/config/studio-board";
import { resolveCampaignDetailsView } from "@/lib/campaign-details-view";
import { useCurrentCampaign } from "@/lib/use-current-campaign";

const { campaignDetails: copy, routes } = studioBoard;

function OverviewRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="cd-overview__row">
      <dt className="cd-overview__label">{label}</dt>
      <dd className="cd-overview__value">{value}</dd>
    </div>
  );
}

function IntakeRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="cd-intake__row">
      <dt className="cd-intake__label">{label}</dt>
      <dd className="cd-intake__value">{value}</dd>
    </div>
  );
}

/** Campaign Details — read-only progress check-in (Phase 1). */
export default function CampaignDetailsScene() {
  const { campaign, ready } = useCurrentCampaign();
  const view = useMemo(() => resolveCampaignDetailsView(campaign), [campaign]);

  if (!ready) {
    return (
      <div className="cd" aria-busy="true">
        <div className="cd-shell cd-shell--loading" />
      </div>
    );
  }

  if (!view.hasCampaign) {
    return (
      <div className="cd">
        <div className="cd-shell cd-shell--empty">
          <p className="cd-eyebrow">{copy.eyebrow}</p>
          <h1 className="cd-title">{copy.empty.title}</h1>
          <p className="cd-lead">{copy.empty.body}</p>
          <Link href={routes.studioBoard} className="cd-btn cd-btn--primary">
            {copy.empty.cta} →
          </Link>
        </div>
        <StudioBoardDevStatus />
      </div>
    );
  }

  return (
    <div className="cd" aria-label="Campaign Details">
      <header className="cd-header">
        <Link href={routes.studioBoard} className="cd-back">
          ← {copy.backLabel}
        </Link>
        <div className="cd-header__copy">
          <p className="cd-eyebrow">{copy.eyebrow}</p>
          <h1 className="cd-title">{copy.pageTitle}</h1>
        </div>
      </header>

      <div className="cd-grid">
        <section className="cd-card" aria-labelledby="cd-overview-title">
          <h2 id="cd-overview-title" className="cd-card__title">
            {copy.sections.overview}
          </h2>
          <dl className="cd-overview">
            <OverviewRow label={copy.overviewLabels.name} value={view.campaignName} />
            <OverviewRow label={copy.overviewLabels.status} value={view.statusLabel} />
            <OverviewRow
              label={copy.overviewLabels.estimatedCompletion}
              value={view.estimatedCompletion}
            />
            <OverviewRow label={copy.overviewLabels.createdDate} value={view.createdDate} />
            <OverviewRow label={copy.overviewLabels.campaignType} value={view.campaignType} />
          </dl>
        </section>

        <section className="cd-card" aria-labelledby="cd-request-title">
          <h2 id="cd-request-title" className="cd-card__title">
            {copy.sections.originalRequest}
          </h2>
          <p className="cd-prompt">{copy.originalRequestPrompt}</p>
          <blockquote className="cd-quote">{view.originalRequest}</blockquote>
        </section>

        <section className="cd-card" aria-labelledby="cd-intake-title">
          <h2 id="cd-intake-title" className="cd-card__title">
            {copy.sections.intakeSummary}
          </h2>
          <dl className="cd-intake">
            <IntakeRow label={copy.intakeLabels.goal} value={view.intakeSummary.goal} />
            <IntakeRow label={copy.intakeLabels.audience} value={view.intakeSummary.audience} />
            <IntakeRow label={copy.intakeLabels.timeline} value={view.intakeSummary.timeline} />
            <IntakeRow label={copy.intakeLabels.budget} value={view.intakeSummary.budget} />
          </dl>
        </section>

        <section className="cd-card cd-card--journey" aria-labelledby="cd-journey-title">
          <h2 id="cd-journey-title" className="cd-card__title">
            {copy.sections.journey}
          </h2>
          <JourneyRail status={view.status} layout="horizontal" />
        </section>

        <section className="cd-card" aria-labelledby="cd-deliverables-title">
          <h2 id="cd-deliverables-title" className="cd-card__title">
            {copy.sections.deliverables}
          </h2>
          {view.deliverables.ready ? (
            <ul className="cd-deliverables__links">
              {view.deliverables.links.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="cd-deliverables__link">
                    {link.label} →
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <div className="cd-deliverables__waiting">
              <p className="cd-deliverables__message">{view.deliverables.message}</p>
              <p className="cd-deliverables__hint">{view.deliverables.hint}</p>
            </div>
          )}
        </section>

        <section className="cd-card" aria-labelledby="cd-updates-title">
          <h2 id="cd-updates-title" className="cd-card__title">
            {copy.sections.updates}
          </h2>
          <p className="cd-updates__hint">{studioBoard.notesCopy.readOnlyHint}</p>
          <ul className="cd-updates">
            {view.studioNotes.map((note, index) => (
              <li key={`${note}-${index}`} className="cd-updates__item">
                {note}
              </li>
            ))}
          </ul>
        </section>
      </div>

      <StudioBoardDevStatus />
    </div>
  );
}
